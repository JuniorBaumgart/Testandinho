package br.upf.agendamento.dto;

public class UsuarioDTO {

}
